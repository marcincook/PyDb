# Połączenie Pythona z bazą danych Sql Serwer

## Biblioteka do zainstalowania 
https://pypi.org/project/pymssql/

## Dokumentacja biblioteki
https://pymssql.readthedocs.io/en/stable/pymssql_examples.html#basic-features-strict-db-api-compliance


## Wydanie wersji 
First create a source distribution with:
$ python setup.py sdist


## Powiadomienia dz∑iękowe 
https://www.youtube.com/watch?v=5EHEG4gMCNs
https://versa-syahptr.github.io/winotify/docs/winotify.html

## Window
https://www.youtube.com/watch?v=iM3kjbbKHQU
https://github.com/TomSchimansky/CustomTkinter/blob/master/examples/complex_example.py

