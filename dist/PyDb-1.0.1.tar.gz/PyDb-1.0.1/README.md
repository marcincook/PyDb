# Połączenie Pythona z bazą danych Sql Serwer

## Biblioteka do zainstalowania 
https://pypi.org/project/pymssql/

## Dokumentacja biblioteki
https://pymssql.readthedocs.io/en/stable/pymssql_examples.html#basic-features-strict-db-api-compliance


## Wydanie wersji 
First create a source distribution with:
$ python setup.py sdist